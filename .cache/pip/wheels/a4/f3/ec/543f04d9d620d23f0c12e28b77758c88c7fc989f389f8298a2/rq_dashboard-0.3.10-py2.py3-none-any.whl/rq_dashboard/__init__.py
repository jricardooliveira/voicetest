# flake8: noqa
from . import default_settings
from .web import blueprint
